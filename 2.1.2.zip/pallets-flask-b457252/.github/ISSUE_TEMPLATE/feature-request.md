---
name: Feature request
about: Suggest a new feature for Flask
---

<!--
Replace this comment with a description of what the feature should do.
Include details such as links to relevant specs or previous discussions.
-->

<!--
Replace this comment with an example of the problem which this feature
would resolve. Is this problem solvable without changes to Flask, such
as by subclassing or using an extension?
-->
